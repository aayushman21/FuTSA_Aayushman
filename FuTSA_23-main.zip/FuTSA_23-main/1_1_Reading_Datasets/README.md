### Day 1: Reading Data

In this notebook, you'll learn how to read data from different types of source files ( Excel, CSV, URL, HTML ) . Go through this notebook as this will be the basic step for all your further assignments. If you are familiar with any of the coding languages it would at max take an hour to go through it.

These are also datasets that you'll be needing.
