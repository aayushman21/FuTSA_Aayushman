Day6/7: Outlier Detection

The final notebook for Week 1 would be this one. It contains one of the least-focused-yet-very-important topic while dealing with data i.e. Outlier Detection using Statistical Methods. Cover this notebook in depth, please.
