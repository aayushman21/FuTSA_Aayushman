# Forecasting using Time Series Analysis

Introductory Material can be found here: https://docs.google.com/document/d/1Q6nH_zP2caOInPJDUPzr_RF88-IQEmnyQ0hRBosY9lo/edit?usp=sharingv 


Some great Medium blogs for reading are: 

[1. Theoretical Aspects](https://medium.com/@varun030403/time-series-forecasting-theoretical-aspects-part-1-9adf7b1e0ce3)

[2. Implemented Time Series Analysis](https://medium.com/coders-mojo/implemented-time-series-analysis-and-forecasting-projects-3adea88b7fe8)


Extra Reading:

[1. FPP](https://otexts.com/fpp2/)
