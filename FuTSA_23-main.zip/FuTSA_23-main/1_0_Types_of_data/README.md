### Day 0: Types of Data - Time Series, Cross-Section & Panel Data

Notebook also contains three YouTube videos, Don't forget to watch them. Also, this notebook is very basic, and would not take more than 15 mins to go through, apart from the videos, thus: Day 0

You can, henceforth, open these notebooks locally in VS Code (or, JupyterLab). Here's a quick video to get you started with Jupyter Notebooks in VS Code: https://youtu.be/9V7AoX0TvSM
